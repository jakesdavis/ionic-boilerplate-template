# ionic-boilerplate-template
A starter boilerplate for Ionic.


# Setting up the workspace
> npm install

> gulp install

> gulp watch